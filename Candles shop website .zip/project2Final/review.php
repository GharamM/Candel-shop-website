<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="cssweb.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <style>
      body{
        font-size: 14pt;
    	  color:#F4DECB;
    	  background-color:#94618E;
    	  font-family:"Times New Roman", Georgia,Garamond,sans-serif;
      }
    </style>
  </head>
  <header>
  <h1><strong>S|H Candles</strong></h1>
  </header>
</div>
  <!-- Begin section  -->
<section id = "leftcolumn">
  <!--Nav element refers to all navigation links that lead to the different options of website-->
  <nav style="order: 2">
    <p>
      <!-- Groups navigation links  -->
      <a class="navBar"  href = "WelcomePage.html" >Home</a>
      <a class="navBar"  href = "index.php"     >Candles</a>
      <a class="navBar"  href = "contactus.html"   >Contact Us</a>
      <a class="navBar"  href = "CandleCare.html"  >Candle Care</a>
      <a class="navBar"  href = "review.php"       >Shopping Cart</a>
      <a class="navBar"  href = "HelpFAQ.html"     >Help & FAQ</a>
      <a class="navBar"  href = "rate us.html"      >Rate us</a>
      <i style="font-size:24px" class="fa">&#xf07a;</i>
    </p>
  </nav>
</section>
  <body>
    <h3 style="color:#552d57">Order Details</h3>
    <div style="background-color: #8a5c8d; opacity:80%;"class="table-responsive">
         <table style="background-color: #834087; opacity:80%;" class="table table-bordered">
              <tr>
                   <th width="40%">Item Name</th>
                   <th width="10%">Quantity</th>
                   <th width="20%">Price</th>
                   <th width="15%">Total</th>
                   <th width="5%">Action</th>
              </tr>
              <?php
              session_start();
              $connect = mysqli_connect("localhost", "root", "", "project");
              if(!empty($_SESSION["shopping_cart"]))
              {
                   $total = 0;
              foreach($_SESSION["shopping_cart"] as $keys => $values)
               {
              if(isset($_GET["action"]))
              {
                       if($_GET["action"] == "delete")
                       {
                            foreach($_SESSION["shopping_cart"] as $keys => $values)
                            {
                                if($values["item_id"] == $_GET["id"])
                                {
                                      unset($_SESSION["shopping_cart"][$keys]);
                                      echo '<script>alert("Item Removed")</script>';
                                      echo '<script>window.location="review.php"</script>';
                                }
                            }
                      }
                }
              ?>
              <tr>
                   <td><?php echo $values["item_name"]; ?></td>
                   <td><?php echo $values["item_quantity"]; ?></td>
                   <td>$ <?php echo $values["item_price"]; ?></td>
                   <td>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>
                   <td><a href="review.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>
              </tr>
              <?php
                        $total = $total + ($values["item_quantity"] * $values["item_price"]);
                   }
              ?>
              <tr>
                   <td colspan="3" align="right">Total</td>
                   <td align="right">$ <?php echo number_format($total, 2); ?></td>
                   <td></td>
              </tr>
              <?php
              }
              ?>
         </table>
    </div>
  </body>
  <footer>
      <h2>Be the first to know</h2>
      <p>Subscribe to stay in the loop on new product launches, promotions, and more.</p>
      <p>
          <input class="search" type = "email" id = "email"
          placeholder = "name@domain.com" width="50%"/>
          <input type = "submit" value = "Submit" />
      </p>
      <h6>Copyright &copy;  2021 S|H Candle.<h6>
      <!-- address element represents contact information for a document -->
      <address>
          Contact us at <a href = "mailto:S|H@candle.com">S|H@candle.com</a>
      </address>
  </footer>
</html>
