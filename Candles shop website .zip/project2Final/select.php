<!DOCTYPE html>
<html>

<head>
	<meta charset = "utf-8">
	<title>Select Results</title>
  <link rel="stylesheet" type="text/css" href="cssweb.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
  <style>
    table{
      color: black;

     }
     </style>
</head>
<body>
  <!-- Begin section  -->
  <section id = "leftcolumn">
				<!--Nav element refers to all navigation links that lead to the different options of website-->
				<nav style="order: 2">
					<p>
						<!-- Groups navigation links  -->
						<a class="navBar"  href = "WelcomePage.html" >Home</a>
						<a class="navBar"  href = "index.php"     >Candles</a>
						<a class="navBar"  href = "contactus.html"   >Contact Us</a>
						<a class="navBar"  href = "CandleCare.html"  >Candle Care</a>
						<a class="navBar"  href = "review.php"       >Shopping Cart</a>
						<a class="navBar"  href = "HelpFAQ.html"     >Help & FAQ</a>
						<a class="navBar"  href = "rate us.html"      >Rate us</a>
						<i style="font-size:24px" class="fa">&#xf07a;</i>
					</p>
				</nav>
			</section>
<?php // build SELECT query
$query = "SELECT * FROM contactinfo";
 // Connect to MySQL
  $servername = "localhost";
  $username = "root";
  $password = "";
  $my_db="project";

    if ( !( $database = mysqli_connect( $servername, $username, $password, $my_db ) ) )
     die( "<p>Could not connect to database</p>" );
      // open project database
    if ( !mysqli_select_db( $database, $my_db) )
      die( "<p>Could not open project database</p>" );

    // query mailings database
    if ( !( $result = mysqli_query( $database,$query) ) )
    {
         print( "<p>Could not execute query!</p>" );
         die( mysqli_error() );
    }
     // end  if
      print("<table>
                    <tr >
                    <th >All OF Information are insert to database:</th>
                    </tr>
               ");

      // fetch each record in result set
      for ( $counter = 0; $row = mysqli_fetch_row( $result ); ++$counter )
      {

          // display results
          foreach ( $row as $key => $value ){
            print( "<tr><td>  $value  </td></tr>" );
            print( "<p>  </p>" );
          }
        } // end for
        print ("</table>");

       mysqli_close( $database );
        ?>
           <!-- end PHP script -->
       </body>

</html>
