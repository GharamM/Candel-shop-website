// form Validation for all infoemation 
function formValidation()
{

	var fname = document.forms["RegForm"]["firstName"];
	var lname = document.forms["RegForm"]["lastName"];
	var getSelectedValue = document.querySelector( 'input[name="gender"]:checked'); 
	var email = document.forms["RegForm"]["email"];
	var nationality = document.forms["RegForm"]["nationality"];
	var phone = document.forms["RegForm"]["tel"];
	var mail_format = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
	var phone_format =/^\([0-9]{3}\) [0-9]{3}-[0-9]{4}$/;

	if (fname.value != ""  &&   isNaN(fname.value) && fname.value.length <= 10  ) {return true;}
	if (lname.value != "" &&   isNaN(fname.value) && fname.value.length <= 10 ) {return true;}
	if(getSelectedValue != null) {return true;}
	if (email.value != "" && email.value.match(email) ) {return true;}
	if (nationality.selectedIndex >= 1)  {return true;}
	if (phone.value != "" && phone.value.match(phone_format) ) {return true;}
	window.alert("Please enter correct information or completed it");
	focus();
	return false;
}