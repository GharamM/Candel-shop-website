
<!DOCTYPE html>
<html>

<head>
	<title>Insert rate</title>
	<link rel="stylesheet" type="text/css" href="cssweb.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
</head>

<body>

			<!-- Begin section  -->
			<section id = "leftcolumn">
				<!--Nav element refers to all navigation links that lead to the different options of website-->
				<nav style="order: 2">
					<p>
						<!-- Groups navigation links  -->
						<a class="navBar"  href = "WelcomePage.html" >Home</a>
						<a class="navBar"  href = "index.php"     >Candles</a>
						<a class="navBar"  href = "contactus.html"   >Contact Us</a>
						<a class="navBar"  href = "CandleCare.html"  >Candle Care</a>
						<a class="navBar"  href = "review.php"       >Shopping Cart</a>
						<a class="navBar"  href = "HelpFAQ.html"     >Help & FAQ</a>
						<a class="navBar"  href = "rate us.html"      >Rate us</a>
						<i style="font-size:24px" class="fa">&#xf07a;</i>
					</p>
				</nav>
			</section>
	<center>
		<?php

		// servername => localhost
		// username => root
		// password => empty
		// database name => project
		$conn = mysqli_connect("localhost", "root", "", "project");

		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}

		// Taking all values from the form data(input)
		$email = $_REQUEST['email'];
		$question1 = $_REQUEST['Q1'];
		$question2 = $_REQUEST['Q2'];
		$comment1 = $_REQUEST['c1'];
		$question3 = $_REQUEST['Q3'];
		$comment2 = $_REQUEST['c2'];
		$question4 = $_REQUEST['Q4'];


		// Performing insert query execution
		// here our table name is rateInfo
		$sql = "INSERT INTO rateInfo VALUES ('$email','$question1','$question2','$comment1','$question3','$comment2','$question4')";

		if(mysqli_query($conn, $sql)){
			echo "<h1 style='color:white'>Thank you for rating us we will take your opinion in consideration.</h1>";

		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}

		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
