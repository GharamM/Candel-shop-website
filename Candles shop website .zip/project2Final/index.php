<?php
 session_start();
 $connect = mysqli_connect("localhost", "root", "", "project");
 if(isset($_POST["add_to_cart"]))
 {
      if(isset($_SESSION["shopping_cart"]))
      {
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
           if(!in_array($_GET["id"], $item_array_id))
           {
                $count = count($_SESSION["shopping_cart"]);
                $item_array = array(
                     'item_id'               =>     $_GET["id"],
                     'item_name'               =>     $_POST["hidden_name"],
                     'item_price'          =>     $_POST["hidden_price"],
                     'item_quantity'          =>     $_POST["quantity"]
                );
                $_SESSION["shopping_cart"][$count] = $item_array;
           }
           else
           {
                echo '<script>alert("Item Already Added")</script>';
                echo '<script>window.location="review.php"</script>';
           }
      }
      else
      {
           $item_array = array(
                'item_id'               =>     $_GET["id"],
                'item_name'               =>     $_POST["hidden_name"],
                'item_price'          =>     $_POST["hidden_price"],
                'item_quantity'          =>     $_POST["quantity"]
           );
           $_SESSION["shopping_cart"][0] = $item_array;
      }
 }
 if(isset($_GET["action"]))
 {
      if($_GET["action"] == "delete")
      {
           foreach($_SESSION["shopping_cart"] as $keys => $values)
           {
                if($values["item_id"] == $_GET["id"])
                {
                     unset($_SESSION["shopping_cart"][$keys]);
                     echo '<script>alert("Item Removed")</script>';
                     echo '<script>window.location="review.php"</script>';
                }
           }
      }
 }
 ?>
 <!DOCTYPE html>
 <html>
      <head>
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
           <link rel="stylesheet" href="cssweb.css">
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
      </head>
      <header>
      <h1><strong>S|H Candles</strong></h1>
      </header>
    </div>
      <!-- Begin section  -->
    <section id = "leftcolumn">
      <!--Nav element refers to all navigation links that lead to the different options of website-->
      <nav style="order: 2">
        <p>
          <!-- Groups navigation links  -->
          <a class="navBar"  href = "WelcomePage.html" >Home</a>
          <a class="navBar"  href = "index.php"     >Candles</a>
          <a class="navBar"  href = "contactus.html"   >Contact Us</a>
          <a class="navBar"  href = "CandleCare.html"  >Candle Care</a>
          <a class="navBar"  href = "review.php"         >Shopping Cart</a>
          <a class="navBar"  href = "HelpFAQ.html"     >Help & FAQ</a>
          <a class="navBar"  href = "rate us.html"                 >Rate us</a>
          <i style="font-size:24px" class="fa">&#xf07a;</i>
        </p>
      </nav>
    </section>
      <body>
           <br />
           <div class="container" style="width:700px;">
                <h3 align="center">OUR PRODUCTS</h3><br />
                <?php
                $query = "SELECT * FROM tbl_product ORDER BY id ASC";
                $result = mysqli_query($connect, $query);
                if(mysqli_num_rows($result) > 0)
                {
                     while($row = mysqli_fetch_array($result))
                     {
                ?>
                <div class>
                     <form method="post" action="index.php?action=add&id=<?php echo $row["id"]; ?>">
                          <div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:10px; margin:20px;" align="center">
                               <img src="<?php echo $row["image"]; ?>" class="img-responsive" /><br />
                               <h4 class="text-info"><?php echo $row["name"]; ?></h4>
                               <h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>
                               <input type="number" name="quantity" class="form-control" style="width:100px" min="1" max="20" value="1" />
                               <input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />
                               <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />
                               <input type="submit" name="add_to_cart" style="margin-top:5px; background-color:#a54bab" class="btn" value="Add to Cart" />
                          </div>
                     </form>
                </div>
                <?php
                     }
                }
                ?>
                <div style="clear:both"></div>
                <br/>
           </div>
           <br/>
      </body>
      <footer>
          <h2>Be the first to know</h2>
          <p>Subscribe to stay in the loop on new product launches, promotions, and more.</p>
          <p>
              <input class="search" type = "email" id = "email"
              placeholder = "name@domain.com" width="50%"/>
              <input type = "submit" value = "Submit" />
          </p>
          <h6>Copyright &copy;  2021 S|H Candle.<h6>
          <!-- address element represents contact information for a document -->
          <address>
              Contact us at <a href = "mailto:S|H@candle.com">S|H@candle.com</a>
          </address>
      </footer>
 </html>
