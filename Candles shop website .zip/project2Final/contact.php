<!DOCTYPE html>
<html>

<head>
	<title>Insert Page(contactInfo)</title>
</head>

<body>
	<center>
		<?php

		// servername => localhost
		// username => root
		// password => empty
		// database name => project
		$conn = mysqli_connect("localhost", "root", "", "project");

		// Check connection
		if($conn === false){
			die("ERROR couldn't connect. "
				. mysqli_connect_error());
		}

		// Taking all values from the form data(input)
		$firstName = $_REQUEST['firstName'];
		$lastName = $_REQUEST['lastName'];
		$gender = $_REQUEST['gender'];
		$birthday = $_REQUEST['birthday'];
		$nationality = $_REQUEST['nationality'];
		$tel = $_REQUEST['tel'];
		$email = $_REQUEST['email'];


		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO contactinfo VALUES ('$firstName','$lastName','$gender','$birthday','$nationality','$tel','$email')";

		if(mysqli_query($conn, $sql)){
			echo "<h3>Thank you for entering the requirements correctly.</h3>";

		} else{
			echo "ERROR sorry! $sql. "
				. mysqli_error($conn);
		}

		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
